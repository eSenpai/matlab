function [w] = wFunc(a, y)
%Suskaiciuoja w

w = a*2.^(y-3);

end

